<?php 
/*
Plugin Name: Global Updates Definitions
Description: I am the captain of this ship, I’ll do my own updates, thanks.
Author: Nenad Zdravkovski
Version: 1.0
*/


// Auto update plugins
add_filter( 'auto_update_plugin', '__return_true' );

// Auto update themes
add_filter( 'auto_update_theme', '__return_true' );

// Update core - disable major updates
add_filter( 'allow_major_auto_core_updates', '__return_false' );

// Update core - just minor versions
add_filter( 'allow_minor_auto_core_updates', '__return_true' );

// Enable update emails
add_filter( 'auto_core_update_send_email', '__return_true' );

?>